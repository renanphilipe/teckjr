# TeckJR — Blog de Tecnologia

Site moderno do TeckJR, construído com **Next.js 14** e pronto para deploy na **Vercel**.

## Stack

- **Next.js 14** (Pages Router)
- **CSS Modules** (sem dependências de UI externas)
- **Google Fonts** — Syne + Space Mono
- Totalmente responsivo (mobile-first)

## Como rodar localmente

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev
# Acesse: http://localhost:3000

# Build de produção
npm run build
npm run start
```

## Estrutura de pastas

```
teckjr/
├── components/
│   ├── Layout.js          # Head + Navbar + Footer
│   ├── Navbar.js          # Navegação responsiva com hamburger
│   ├── Footer.js
│   ├── PostCard.js        # Card reutilizável de postagem
│   └── CategoryPage.js    # Layout padrão de categoria
├── pages/
│   ├── index.js           # Home
│   ├── hardware.js
│   ├── software.js
│   ├── promocoes.js
│   ├── fornecedores.js
│   └── 404.js
├── styles/
│   └── globals.css        # Variáveis CSS e estilos base
└── public/                # Favicon e assets estáticos
```

## Deploy na Vercel

### Opção 1 — Via GitHub (recomendado)

1. Crie um repositório no GitHub e faça push do projeto:
```bash
git init
git add .
git commit -m "feat: initial TeckJR website"
git remote add origin https://github.com/SEU_USER/teckjr.git
git push -u origin main
```

2. Acesse [vercel.com](https://vercel.com) → **Add New Project**
3. Importe o repositório do GitHub
4. Clique em **Deploy** — a Vercel detecta automaticamente o Next.js ✅

### Opção 2 — Via CLI

```bash
npm i -g vercel
vercel
```

## Adicionando conteúdo real

Os posts estão como dados estáticos nas páginas. Para escalar, você pode:

- Integrar com **Contentful**, **Sanity** ou **Notion API**
- Usar arquivos **MDX** em `/content/posts/`
- Conectar ao **Blogger API** do blog original

## Customizações rápidas

Edite as variáveis CSS em `styles/globals.css` para mudar cores, fontes e espaçamentos do tema.
