import Layout from './Layout'
import PostCard from './PostCard'
import styles from './CategoryPage.module.css'

export default function CategoryPage({ title, description, icon, posts, color = 'var(--accent)' }) {
  return (
    <Layout title={`${title} — TeckJR`} description={description}>
      <section className={styles.hero} style={{ '--cat-color': color }}>
        <div className="container">
          <div className={styles.heroInner}>
            <span className={styles.icon}>{icon}</span>
            <div>
              <h1 className={styles.title}>{title}</h1>
              <p className={styles.desc}>{description}</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.posts}>
        <div className="container">
          {posts.length > 0 ? (
            <div className={styles.grid}>
              {posts.map((post, i) => (
                <PostCard key={i} post={post} />
              ))}
            </div>
          ) : (
            <div className={styles.empty}>
              <p>Em breve novos conteúdos aqui.</p>
            </div>
          )}
        </div>
      </section>
    </Layout>
  )
}
