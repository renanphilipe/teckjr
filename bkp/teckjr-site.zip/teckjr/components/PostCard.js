import Link from 'next/link'
import styles from './PostCard.module.css'

export default function PostCard({ post, featured = false }) {
  return (
    <article className={`${styles.card} ${featured ? styles.featured : ''}`}>
      {post.badge && (
        <span className={styles.badge} style={{ '--badge-color': post.badgeColor }}>
          {post.badge}
        </span>
      )}
      <div className={styles.category}>{post.category}</div>
      <h2 className={styles.title}>{post.title}</h2>
      <p className={styles.excerpt}>{post.excerpt}</p>
      <div className={styles.footer}>
        <time className={styles.date}>{post.date}</time>
        <Link href={post.href} className={styles.readMore}>
          Ler mais
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M1 7h12M8 2l5 5-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </Link>
      </div>
    </article>
  )
}
