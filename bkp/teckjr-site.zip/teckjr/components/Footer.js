import Link from 'next/link'
import styles from './Footer.module.css'

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={`${styles.inner} container`}>
        <div className={styles.brand}>
          <Link href="/" className={styles.logo}>
            <span className={styles.acc}>Teck</span>JR
          </Link>
          <p className={styles.tagline}>Tecnologia que faz sentido.</p>
        </div>

        <div className={styles.cols}>
          <div className={styles.col}>
            <h4 className={styles.colTitle}>Categorias</h4>
            <Link href="/hardware" className={styles.colLink}>Hardware</Link>
            <Link href="/software" className={styles.colLink}>Software</Link>
            <Link href="/promocoes" className={styles.colLink}>Promoções</Link>
            <Link href="/fornecedores" className={styles.colLink}>Fornecedores</Link>
          </div>
          <div className={styles.col}>
            <h4 className={styles.colTitle}>Blog</h4>
            <Link href="/" className={styles.colLink}>Últimas Postagens</Link>
            <Link href="/hardware" className={styles.colLink}>Dicas de Hardware</Link>
            <Link href="/software" className={styles.colLink}>Reviews de Software</Link>
          </div>
        </div>
      </div>

      <div className={styles.bottom}>
        <div className="container">
          <p className={styles.copy}>
            © {new Date().getFullYear()} TeckJR. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
