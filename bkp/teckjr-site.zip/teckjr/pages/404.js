import Layout from '../components/Layout'
import Link from 'next/link'
import styles from './404.module.css'

export default function NotFound() {
  return (
    <Layout title="404 — TeckJR">
      <div className={styles.wrap}>
        <div className={styles.code}>404</div>
        <h1 className={styles.title}>Página não encontrada</h1>
        <p className={styles.desc}>Ops! Este endereço não existe ou foi movido.</p>
        <Link href="/" className={styles.btn}>← Voltar ao início</Link>
      </div>
    </Layout>
  )
}
