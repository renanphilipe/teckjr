import CategoryPage from '../components/CategoryPage'

const posts = [
  {
    title: 'Guia completo: escolhendo sua placa de vídeo em 2025',
    excerpt: 'RTX 4000, RX 7000 ou Intel Arc? Comparamos desempenho, custo-benefício e compatibilidade para cada faixa de preço.',
    date: '18 Mar 2025',
    category: 'Hardware',
    href: '#',
  },
  {
    title: 'Memória RAM: DDR4 vs DDR5 — vale a pena migrar?',
    excerpt: 'Analisamos as diferenças reais de desempenho, preços e compatibilidade entre as gerações de memória RAM.',
    date: '15 Mar 2025',
    category: 'Hardware',
    href: '#',
  },
  {
    title: 'SSD NVMe: os modelos mais rápidos para montar seu PC',
    excerpt: 'Listamos os melhores SSDs NVMe disponíveis no mercado brasileiro, com análise de velocidade e durabilidade.',
    date: '12 Mar 2025',
    category: 'Hardware',
    href: '#',
  },
  {
    title: 'Como escolher uma fonte de alimentação confiável',
    excerpt: 'Evite dores de cabeça: saiba como calcular a potência necessária e quais marcas são mais recomendadas.',
    date: '08 Mar 2025',
    category: 'Hardware',
    href: '#',
  },
]

export default function Hardware() {
  return (
    <CategoryPage
      title="Hardware"
      description="Componentes, montagem, benchmarks e dicas técnicas para construir o PC dos seus sonhos."
      icon="🖥️"
      posts={posts}
      color="var(--accent)"
    />
  )
}
