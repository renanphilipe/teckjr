import Layout from '../components/Layout'
import Link from 'next/link'
import styles from './fornecedores.module.css'

const suppliers = [
  {
    name: 'KaBuM!',
    desc: 'Uma das maiores lojas de tecnologia do Brasil, com entrega rápida e grande variedade de produtos.',
    tags: ['Hardware', 'Periféricos', 'Montagem'],
    url: 'https://www.kabum.com.br',
    rating: 5,
  },
  {
    name: 'Pichau',
    desc: 'Especializada em PC Gamer, com preços competitivos e excelente suporte pós-venda.',
    tags: ['Gaming', 'Componentes', 'PCs Prontos'],
    url: 'https://www.pichau.com.br',
    rating: 5,
  },
  {
    name: 'Terabyte Shop',
    desc: 'Focada em entusiastas, com produtos de ponta e ótima curadoria para builders exigentes.',
    tags: ['Entusiasta', 'Watercooling', 'RGB'],
    url: 'https://www.terabyteshop.com.br',
    rating: 4,
  },
  {
    name: 'Shopee',
    desc: 'Marketplace com preços agressivos para periféricos, gadgets e acessórios tech com frete grátis.',
    tags: ['Marketplace', 'Gadgets', 'Promoções'],
    url: 'https://shopee.com.br',
    rating: 4,
  },
  {
    name: 'Amazon Brasil',
    desc: 'Confiabilidade internacional com entrega rápida e política de devolução eficiente.',
    tags: ['Internacional', 'Eletrônicos', 'Prime'],
    url: 'https://www.amazon.com.br',
    rating: 4,
  },
  {
    name: 'Mercado Livre',
    desc: 'O maior marketplace da América Latina. Ideal para encontrar produtos novos e usados com garantia.',
    tags: ['Marketplace', 'Novo & Usado', 'Parcelamento'],
    url: 'https://www.mercadolivre.com.br',
    rating: 4,
  },
]

function Stars({ count }) {
  return (
    <div className={styles.stars}>
      {[1,2,3,4,5].map(i => (
        <span key={i} className={i <= count ? styles.starOn : styles.starOff}>★</span>
      ))}
    </div>
  )
}

export default function Fornecedores() {
  return (
    <Layout title="Fornecedores — TeckJR" description="Os melhores fornecedores e lojas de tecnologia do Brasil, curados pela equipe TeckJR.">
      <section className={styles.hero}>
        <div className="container">
          <div className={styles.heroInner}>
            <span className={styles.icon}>🔗</span>
            <div>
              <h1 className={styles.title}>Fornecedores</h1>
              <p className={styles.desc}>Lojas confiáveis e bem avaliadas para comprar tecnologia no Brasil.</p>
            </div>
          </div>
        </div>
      </section>

      <section className={styles.grid}>
        <div className="container">
          <div className={styles.cards}>
            {suppliers.map((s, i) => (
              <div key={i} className={styles.card}>
                <div className={styles.cardTop}>
                  <div>
                    <h2 className={styles.name}>{s.name}</h2>
                    <Stars count={s.rating} />
                  </div>
                  <Link href={s.url} target="_blank" rel="noopener noreferrer" className={styles.visit}>
                    Visitar
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path d="M2.5 9.5L9.5 2.5M9.5 2.5H4.5M9.5 2.5V7.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </Link>
                </div>
                <p className={styles.cardDesc}>{s.desc}</p>
                <div className={styles.tags}>
                  {s.tags.map(tag => (
                    <span key={tag} className={styles.tag}>{tag}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  )
}
