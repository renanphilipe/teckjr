import Layout from '../components/Layout'
import PostCard from '../components/PostCard'
import Link from 'next/link'
import styles from './index.module.css'

const featuredPost = {
  title: 'Bem-vindo ao TeckJR!',
  excerpt: 'Seu portal de tecnologia com dicas de hardware, reviews de software, promoções imperdíveis e os melhores fornecedores do mercado. Fique por dentro das últimas novidades do mundo tech.',
  date: '20 Mar 2025',
  category: 'Destaque',
  badge: 'Novo',
  badgeColor: 'var(--accent)',
  href: '#',
}

const latestPosts = [
  {
    title: 'Os melhores processadores de 2025',
    excerpt: 'Um guia completo para escolher o processador ideal para o seu setup, seja para gaming, trabalho ou criação de conteúdo.',
    date: '18 Mar 2025',
    category: 'Hardware',
    href: '/hardware',
  },
  {
    title: 'Top 10 softwares gratuitos que todo usuário deve ter',
    excerpt: 'Selecionamos as melhores ferramentas gratuitas para produtividade, segurança e entretenimento no seu PC.',
    date: '15 Mar 2025',
    category: 'Software',
    href: '/software',
  },
  {
    title: 'Promoções imperdíveis na Shopee — Semana Tech',
    excerpt: 'Curadoria das melhores ofertas em periféricos, componentes e gadgets com os menores preços da semana.',
    date: '13 Mar 2025',
    category: 'Promoções',
    href: '/promocoes',
  },
  {
    title: 'Melhores fornecedores nacionais de hardware',
    excerpt: 'Lista atualizada dos fornecedores mais confiáveis do Brasil para montar ou atualizar o seu PC com segurança.',
    date: '10 Mar 2025',
    category: 'Fornecedores',
    href: '/fornecedores',
  },
]

const categories = [
  { href: '/hardware', label: 'Hardware', icon: '🖥️', desc: 'Componentes e dicas', color: '#00e5ff' },
  { href: '/software', label: 'Software', icon: '💾', desc: 'Apps e ferramentas', color: '#7b5ea7' },
  { href: '/promocoes', label: 'Promoções', icon: '🏷️', desc: 'Ofertas e descontos', color: '#ff4d6d' },
  { href: '/fornecedores', label: 'Fornecedores', icon: '🔗', desc: 'Lojas confiáveis', color: '#ffd166' },
]

export default function Home() {
  return (
    <Layout title="TeckJR — Tecnologia que faz sentido" description="Hardware, Software, Promoções e Fornecedores. O melhor do mundo tech em um só lugar.">

      {/* HERO */}
      <section className={styles.hero}>
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroTag}>
            <span className={styles.heroDot} />
            Blog de Tecnologia
          </div>
          <h1 className={styles.heroTitle}>
            Tecnologia que<br />
            <span className={styles.heroAccent}>faz sentido.</span>
          </h1>
          <p className={styles.heroSub}>
            Hardware, Software, Promoções e Fornecedores.<br />
            Tudo que você precisa saber sobre tech — em um só lugar.
          </p>
          <div className={styles.heroActions}>
            <Link href="/hardware" className={styles.btnPrimary}>Explorar conteúdo</Link>
            <Link href="/promocoes" className={styles.btnSecondary}>Ver promoções 🏷️</Link>
          </div>
        </div>
        <div className={styles.heroBg} aria-hidden="true">
          <div className={styles.blob1} />
          <div className={styles.blob2} />
          <div className={styles.grid} />
        </div>
      </section>

      {/* CATEGORIES */}
      <section className={styles.cats}>
        <div className="container">
          <div className={styles.catsGrid}>
            {categories.map((cat) => (
              <Link key={cat.href} href={cat.href} className={styles.catCard} style={{ '--c': cat.color }}>
                <span className={styles.catIcon}>{cat.icon}</span>
                <div>
                  <div className={styles.catLabel}>{cat.label}</div>
                  <div className={styles.catDesc}>{cat.desc}</div>
                </div>
                <svg className={styles.catArrow} width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M3 8h10M9 3l5 5-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED */}
      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Destaque</h2>
            <div className={styles.sectionLine} />
          </div>
          <PostCard post={featuredPost} featured />
        </div>
      </section>

      {/* LATEST */}
      <section className={styles.section}>
        <div className="container">
          <div className={styles.sectionHeader}>
            <h2 className={styles.sectionTitle}>Últimas Postagens</h2>
            <div className={styles.sectionLine} />
          </div>
          <div className={styles.postsGrid}>
            {latestPosts.map((post, i) => (
              <PostCard key={i} post={post} />
            ))}
          </div>
        </div>
      </section>

    </Layout>
  )
}
