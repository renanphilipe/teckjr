import CategoryPage from '../components/CategoryPage'

const posts = [
  {
    title: 'Top 10 programas gratuitos que todo PC deve ter em 2025',
    excerpt: 'De antivírus a editores de imagem: selecionamos os melhores softwares gratuitos para produtividade e segurança.',
    date: '17 Mar 2025',
    category: 'Software',
    href: '#',
  },
  {
    title: 'Windows 11 vs Windows 10 em 2025 — qual usar?',
    excerpt: 'Uma análise honesta sobre estabilidade, recursos, compatibilidade e desempenho após anos de atualizações.',
    date: '14 Mar 2025',
    category: 'Software',
    href: '#',
  },
  {
    title: 'Melhores IDEs e editores de código para programadores',
    excerpt: 'VS Code, Neovim, Rider ou JetBrains? Qual editor combina com o seu fluxo de trabalho e linguagem preferida.',
    date: '10 Mar 2025',
    category: 'Software',
    href: '#',
  },
  {
    title: 'Ferramentas de IA para aumentar sua produtividade',
    excerpt: 'Como usar IAs como assistente de escrita, gerador de código e ferramenta de organização no dia a dia.',
    date: '05 Mar 2025',
    category: 'Software',
    href: '#',
  },
]

export default function Software() {
  return (
    <CategoryPage
      title="Software"
      description="Reviews, tutoriais e recomendações dos melhores aplicativos e ferramentas para o seu dia a dia."
      icon="💾"
      posts={posts}
      color="var(--accent2)"
    />
  )
}
