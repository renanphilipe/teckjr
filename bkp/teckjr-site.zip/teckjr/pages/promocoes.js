import CategoryPage from '../components/CategoryPage'

const posts = [
  {
    title: 'Melhores ofertas de periféricos na Shopee — Semana Tech',
    excerpt: 'Teclados mecânicos, mouses gamer e headsets com descontos de até 60%. Aproveite antes que acabe.',
    date: '20 Mar 2025',
    category: 'Promoções',
    badge: 'Ativo',
    badgeColor: '#ff4d6d',
    href: '#',
  },
  {
    title: 'Componentes em promoção: SSDs e memórias RAM',
    excerpt: 'Preços históricos em SSDs NVMe e kits DDR4 e DDR5. Ideal para quem está montando ou atualizando o PC.',
    date: '16 Mar 2025',
    category: 'Promoções',
    href: '#',
  },
  {
    title: 'Cuponagem: como economizar ainda mais nas compras tech',
    excerpt: 'Estratégias para empilhar cupons, cashback e promoções relâmpago e pagar menos em produtos de tecnologia.',
    date: '10 Mar 2025',
    category: 'Promoções',
    href: '#',
  },
]

export default function Promocoes() {
  return (
    <CategoryPage
      title="Promoções"
      description="Curadoria das melhores ofertas em tecnologia — periféricos, componentes e gadgets com os menores preços."
      icon="🏷️"
      posts={posts}
      color="var(--accent3)"
    />
  )
}
